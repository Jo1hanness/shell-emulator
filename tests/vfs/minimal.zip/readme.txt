minimal vfs
